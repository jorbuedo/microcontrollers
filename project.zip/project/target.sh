#!/bin/bash

./cmake.sh target uart lcd twimastertimeout mpu6050 mpu6050dmp6 nrf24l01 spi base64
